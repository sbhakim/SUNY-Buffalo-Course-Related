While compling rsa_encrypt_openssl_3.c received a Segmentation fault. 
