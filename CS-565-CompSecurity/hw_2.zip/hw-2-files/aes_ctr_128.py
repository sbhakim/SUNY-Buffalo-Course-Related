#!/usr/bin/env python3
import sys
import os
import time
from Crypto.Cipher import AES
from Crypto.Util import Counter
from Crypto.Random import get_random_bytes

# AES key size (in bits)
AES_KEY_SIZE = 128

# AES block size (in bytes)
AES_BLOCK_SIZE = 16


def aes_ctr_encrypt(data, key):
    iv = get_random_bytes(AES_BLOCK_SIZE)
    ctr = Counter.new(AES_BLOCK_SIZE * 8, initial_value=int.from_bytes(iv, byteorder='big'))
    cipher = AES.new(key, AES.MODE_CTR, counter=ctr)
    ciphertext = cipher.encrypt(data)
    return (iv + ciphertext)


def aes_ctr_decrypt(data, key):
    iv = data[:AES_BLOCK_SIZE]
    ciphertext = data[AES_BLOCK_SIZE:]
    ctr = Counter.new(AES_BLOCK_SIZE * 8, initial_value=int.from_bytes(iv, byteorder='big'))
    cipher = AES.new(key, AES.MODE_CTR, counter=ctr)
    plaintext = cipher.decrypt(ciphertext)
    return plaintext


def main():
    # Get the filename from command line argument
    if len(sys.argv) < 2:
        print("Error: Please provide a filename.")
        sys.exit(1)
    filename = sys.argv[1]

    # Read file contents
    with open(filename, 'rb') as f:
        data = f.read()

    # Generate a 128-bit AES key
    key = get_random_bytes(AES_KEY_SIZE // 8)

    # Encrypt the data using AES CTR mode
    start_time = time.time()
    encrypted_data = aes_ctr_encrypt(data, key)
    encrypt_time = (time.time() - start_time) * 1000

    # Decrypt the data using AES CTR mode
    start_time = time.time()
    decrypted_data = aes_ctr_decrypt(encrypted_data, key)
    decrypt_time = (time.time() - start_time) * 1000

    # Compare the original data with the decrypted data
    if data == decrypted_data:
        print("Encryption and decryption successful for AES CTR 128-bit!")
    else:
        print("Error: encryption and decryption did not match.")

    # Write the encrypted data to a new file
    with open(filename + '.enc', 'wb') as f:
        f.write(encrypted_data)

    # Calculate encryption speed per byte in KB/ms
    encrypt_speed = len(data) / encrypt_time / 1024
    decrypt_speed = len(data) / decrypt_time / 1024
    print(f"Encryption time: {encrypt_time:.3f} ms")
    print(f"Decryption time: {decrypt_time:.3f} ms")
    print(f"Encryption speed: {encrypt_speed:.3f} KB/ms")
    print(f"Decryption speed: {decrypt_speed:.3f} KB/ms")


if __name__ == '__main__':
    main()
